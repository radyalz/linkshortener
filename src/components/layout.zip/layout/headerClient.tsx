"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { navItems } from "@/components/layout/navItems";

type HeaderNavClientProps = { isLoggedIn: boolean };

export function HeaderClient({ isLoggedIn }: HeaderNavClientProps) {
  const pathname = usePathname();
  const visibleNavItems = navItems.filter((item) => {
    if (item.href === "/dashboard") {
      return isLoggedIn;
    }
    return true;
  });
  const activeIndex = visibleNavItems.findIndex((item) => item.isActive(pathname));
  const safeActiveIndex = activeIndex === -1 ? 0 : activeIndex;
  const itemWidth = `${100 / visibleNavItems.length}%`;
  return (
    <nav className="relative hidden rounded-sm  bg-muted/40 p-1 md:flex gap-2">
      <span
        className="absolute bottom-1 top-1 rounded-lg bg-purple-950 transition-all duration-300 ease-out"
        style={{
          width: `calc(${itemWidth} - 0.3rem)`,
          transform: `translateX(${safeActiveIndex * 100}%)`,
        }}
      />
      {visibleNavItems.map((item) => {
        const active = item.isActive(pathname);
        return (
          <Link
            key={item.href}
            href={item.href}
            prefetch
            className={cn(
              "relative z-10 flex h-8 min-w-24 items-center justify-center rounded-lg px-4 text-sm font-medium transition-all duration-200",
              active
                ? "text-purple-50"
                : "text-purple-900/60 hover:bg-purple-400/10 hover:text-purple-950 dark:text-purple-200/60 dark:hover:bg-purple-300/10 dark:hover:text-purple-50",
            )}
          >
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}
