import { FeaturesSection } from "@/components/landing/featuresSection";
import { HeroSection } from "@/components/landing/heroSection";
import { SiteHeader } from "@/components/landing/header";
import { WorkflowSection } from "@/components/landing/workflowSection";

export default function HomePage() {
  return (
    <main className="min-h-screen px-6 py-6">
      <SiteHeader />
      <HeroSection />
      <FeaturesSection />
      <WorkflowSection />
    </main>
  );
}