import Link from "next/link";

import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/ui/themeToggle";

export function SiteHeader() {
  return (
    <header className="glass-panel sticky top-4 z-20 mx-auto flex max-w-6xl items-center justify-between rounded-2xl px-4 py-3">
      <Link href="/" className="text-lg font-semibold tracking-tight">
        <span className="gold-gradient-text">ShortLink</span>
      </Link>

      <nav className="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
        <a href="#features" className="transition hover:text-foreground">
          Features
        </a>

        <a href="#workflow" className="transition hover:text-foreground">
          Workflow
        </a>

        <Link href="/dashboard" className="transition hover:text-foreground">
          Dashboard
        </Link>
      </nav>

      <div className="flex items-center gap-2">
        <ThemeToggle />

        <Button asChild variant="outline" size="sm">
          <Link href="/login">Log in</Link>
        </Button>

        <Button asChild variant="gold" size="sm">
          <Link href="/signup">Sign up</Link>
        </Button>
      </div>
    </header>
  );
}
